﻿namespace simpleCommerce_Utility
{
    public static class WC
    {

        public const string SessionCart = "ShoppingCartSession";

        public const string SessionInquiryId = "InquirySession";

        public const string AdminRole = "Admin";

        public const string CustomerRole = "Customer";

        public const string AdminMail = "hemsininagasi@gmail.com";

        public const string Success = "Success";

        public const string Error = "Error";

        public const string NoImageFilePath = @"\img\no-image.jpg";
    }
}
