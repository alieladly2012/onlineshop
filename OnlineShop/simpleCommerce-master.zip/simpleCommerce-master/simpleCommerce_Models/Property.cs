﻿namespace simpleCommerce_Models
{
    public class Property
    {
        public Guid PropertyId { get; set; }
        public string? Name { get; set; }

    }
}
